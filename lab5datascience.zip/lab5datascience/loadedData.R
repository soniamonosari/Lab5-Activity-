library(shiny)
library(datasets)

ui <- fluidPage(
  titlePanel("Dataset"),
  sidebarLayout(
    sidebarPanel(
      selectInput(inputId = "dataset", label = "Choose a dataset:",
                  choices = c("Rock", "Pressure", "Cars", "Iris")),
      numericInput(inputId = "obs", label = "Number of observations to view:",
                   value = 10)
    ),
    mainPanel(
      tabsetPanel(type = "tabs",
                  tabPanel("Summary", verbatimTextOutput("summary")),
                  tabPanel("Table", tableOutput("view")))
    )
  )
)


server <- function(input, output){
  datasetInput <- reactive({
    switch(input$dataset,
           "Rock" = rock,
           "Pressure" = pressure,
           "Cars" = cars,
           "Iris" = iris)
  })
  
  output$summary <- renderPrint({
    dataset <- datasetInput()
    summary(dataset)
  })
  
  output$view <- renderTable({
    head(datasetInput(), n = input$obs)
  })
  
  
}


shinyApp(ui = ui, server = server)
shinyApp::runApp()