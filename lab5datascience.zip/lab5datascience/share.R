library(shiny)

runGitHub("Lab5-Activity-", "soniamonosari")
runUrl("https://github.com/soniamonosari/Lab5-Activity-/blob/main/app.R")