library(shiny)
library(datasets)

ui <- fluidPage(
  titlePanel("Downloading Data"),
  sidebarLayout(
    
    sidebarPanel(
      selectInput("dataset", "Choose a dataset:",
                  choices = c("Rock", "Pressure", "Cars", "Iris")),
      downloadButton("downloadData", "Download")
      
    ),
    
    mainPanel(
      tableOutput("table")
      
    )
  )
)



server <- function(input, output) {
  datasetInput <- reactive({
    switch(input$dataset,
           "Rock" = rock,
           "Pressure" = pressure,
           "Cars" = cars,
           "Iris" = iris)
    
  })
  output$table <- renderTable({
    
    datasetInput()
  })
  output$downloadData <- downloadHandler(
    
    filename = function() {
      paste(input$dataset, ".csv", sep = "")
      
    },
    content = function(file) {
      
      write.csv(datasetInput(), file, row.names = FALSE)
    }
  )
}

shinyApp(ui = ui, server = server)
shinyApp::runApp()